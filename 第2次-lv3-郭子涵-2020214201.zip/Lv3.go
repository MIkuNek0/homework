package main

import (
	"fmt"
)

func Receiver(v string,p *Mainvideo) {
	switch v{
		case "点赞": 	p.Like++
		case "投币":		p.Coin++
		case "收藏":		p.Collect++
		case "转发":		p.Forward++
		case "一键三连":	{
			p.Like++
			p.Coin++
			p.Collect++
		}

	}
}

type Author struct {        //作者
	Name string             //名字
	VIP bool                //是否是大会员
	Icon string             //头像
	Signature string        //签名
	Focus int               //关注人数
}

type Videodata struct {		//视频
	Title string            //名字
	Content string			//视频内容
	Play int				//播放量
	Danmu int				//弹幕
}

type Mainvideo struct {		//主要视频
	Videodata
	Like int				//点赞
	Coin int				//投币
	Collect int				//收藏
	Forward int				//转发
}

func main() {
	a := Author{
		Name:      "籽岷",
		VIP:       true,
		Icon:      "Zi Min",
		Signature: "12355 青春守护者计划 志愿者 电竞专业 人民教师",
		Focus:     2347000,
	}
	b := Mainvideo{
		Videodata: Videodata{
			Title:   "不 讲 武 德",
			Content: "xxxx",
			Play:    21000,
			Danmu:   409,
		},
		Like:    7509,
		Coin:    694,
		Collect: 316,
		Forward: 77,
	}
	fmt.Println("作者：")
	fmt.Println(a)
	fmt.Println("视频内容：")
	fmt.Println(b)
	for true {
		var c string
		fmt.Scanf("%s", &c)
		Receiver(c, &b)
		fmt.Println("操作完成:")
		fmt.Println(b)
	}
}