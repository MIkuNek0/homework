package main

import (
	"fmt"
)

func main(){
	var a,c int
	var b string
	fmt.Scanln(&a,&b,&c)
	if b=="+" {
		fmt.Println(a+c)
	}
	if b=="-" {
		fmt.Println(a-c)
	}
	if b=="*" {
		fmt.Println(a*c)
	}
	if b=="/" {
		fmt.Println(a/c)
	}
}