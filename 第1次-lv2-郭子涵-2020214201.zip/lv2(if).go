package main

import (
	"fmt"
)

func count(x int,y rune,z int) {
	if y=='+' {
		z=x+z
	}
	if y=='-' {
		z=x-z
	}
	if y=='*' {
		z=x*z
	}
	if y=='/' {
		z=x/z
	}
	if y=='%' {
		z=x%z
	}
	fmt.Println(z)
}

func main() {
	var a rune
	var b,c int
	for {
		fmt.Scanf("%d%c%d",&b,&a,&c)
		count(b,a,c)
	}
}