package main

import "fmt"

func main(){
	var i,j float64
	for i = 2; i >=-2 ; i=i-0.06 {
		for j = -1.2; j <=1.2 ; j=j+0.025 {
			if (i*i + j*j - 1)*(i*i + j*j - 1)*(i*i + j*j - 1) - i*i*i*j*j <= 0 {
				fmt.Print("*")
			}else {
				fmt.Print(" ")
			}
		}
		fmt.Println()
	}
}
