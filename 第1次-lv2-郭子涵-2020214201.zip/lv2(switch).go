package main

import (
	"fmt"
)

func compute(x int,y rune,z int) {
	switch y {
		case '+' :z = x + z
		case '-' :z = x - z
		case '*' :z = x * z
		case '/' :z = x / z
		case '%' :z = x % z
	}
	fmt.Println(z)
}

func main() {
	var a rune
	var b,c int
	for {
		fmt.Scanf("%d%c%d",&b,&a,&c)
		compute(b,a,c)
	}
}